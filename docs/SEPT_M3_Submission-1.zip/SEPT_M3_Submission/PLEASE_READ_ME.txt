LINKS:
	Trello: https://trello.com/invite/b/r8S0CuUT/b7f0fd0358e9d7d8faae465ca6b5255e/major-project
		TRELLO CONTAINS OUR DOD's and PRODUCT BACKLOG. 
		FIND DoD's IN EACH TRELLO PBI CARD
	
	Github: https://github.com/RMIT-SEPT/majorproject-4-wed-18-30-3

ACCESS DEPLOYED APPLICATION ON AWS:
	http://ec2-34-204-47-86.compute-1.amazonaws.com:3000/register
		Note: Some issues exist with timezone conversion from the AWS server to AEDT resulted in default bookings 
		not properly converting to their intended 9am-5pm timeslots. 
		
BUILDING AND RUNNING BACK END:

	USING INTELLIJ:
	For ease of use, we recommend opening the backend in Intellij to build the back end. 
	First, open the project using Open Project, select the POM.xml file located in BackEnd > MajorProject and open as a project.
	Utilise Maven to download necessary dependencies.
	To run, right-click and run the DemoApplication File located:
	majorproject-4-wed-18-30-3\BackEnd\MajorProject\src\main\java\labwed18303\demo
	Note: This will spend approximately half a minute initialising some default content.

BUILDING AND RUNNING FRONT END:
	Prequisites: Node.js / node_modules
	Open in a relevant terminal: majorproject-4-wed-18-30-3\FrontEnd\frontend-react
	Input command: npm install
	Input command: npm start

